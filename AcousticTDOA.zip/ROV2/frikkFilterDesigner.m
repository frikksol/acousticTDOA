function [ b ] = frikkFilterDesigner( centerFreq, pBandwidth, sBandWidth, Fs )
%This function creates a bandpass filter with center frequency at
%centerFreq and with a passband with of pBandwidt(or pBandwidth/2 to each
%side from centerFreq). sBandwidth is the width of the slope on each side
%of the passband. Fs is the sampling frequency.

pbw = pBandwidth/2;
sbw = sBandWidth/2;
cf = centerFreq;
pbAtt = 1;
sbAtt = 80;

filterDesign1 = fdesign.bandpass(cf-sbw, cf-pbw, cf+pbw, cf+sbw, sbAtt, pbAtt, sbAtt, Fs);
Hd1 = design(filterDesign1,'equiripple'); %FIR equiripple design
b = Hd1.numerator;

end

