function [ x, y ] = calculateProjectedCoordinates( D, v, tsa, tsb, tsc, xa, ya, za, xb, yb, zb, xc, yc, zc )
%Designed by Frikk H Solberg
% funciton calculates the projected coordinates using a simplified method
% from the paper XX. 

dsa = v*tsa;
dsb = v*tsb;
dsc = v*tsc;

%Projecting to plane to move from 3D to 2D
dsaProjected = sqrt(dsa*dsa - D*D);
dsbProjected = sqrt(dsb*dsb - D*D);
dscProjected = sqrt(dsc*dsc - D*D);

%Calculating positions
x = (dsaProjected*dsaProjected - dsbProjected*dsbProjected + xb*xb )/(2*xb);
y = ((dsaProjected*dsaProjected - dscProjected*dscProjected + xc*xc + yc*yc)/(2*yc)) - ((xc)/(yc))*x;

end

