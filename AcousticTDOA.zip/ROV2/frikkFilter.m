function [ Y ] = frikkFilter( X, centerFreq, pBandwidth, sBandWidth, Fs )
pbw = pBandwidth/2;
sbw = sBandWidth/2;
cf = centerFreq;
pbAtt = 1;
sbAtt = 80;

filterDesign1 = fdesign.bandpass(cf-sbw, cf-pbw, cf+pbw, cf+sbw, sbAtt, pbAtt, sbAtt, Fs);
Hd1 = design(filterDesign1,'equiripple'); %FIR equiripple design
filter1 = Hd1.numerator;
Y = filter(filter1, 1, X);

end

