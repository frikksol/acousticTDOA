%Creating test signals
%% Setup
f1 = 35000; %Frequency of first pulse
f2 = 40000; %Frequency of second pulse
f3 = 45000; %Frequency of third pulse
Fs = 300000; %Samlpling frequency, Should be no poblem to change this
%Fs = 2*f1

%creating sines of length t with the different frequencies
t = 0:(1/Fs):1;
x1 = sin(2*pi*f1*t);
x2 = sin(2*pi*f2*t);
x3 = sin(2*pi*f3*t);

%Chooseing number of elements from x1, x2 and x3 to create pulse of certain
%number of cycles. Crude way of doing it, needs rework. 
x1Length = 24*6;
x2Length = 21*6;
x3Length = 19*6;

temp = zeros(1, Fs/10);

%Putting together a number of pulses and zero padding so all the signals
%has the same number of points
x1Sig = [x1(1:x1Length) temp];%temp(x1Length:end)];
x2Sig = [x2(1:x2Length) temp];%temp(x2Length:end)];
x3Sig = [x3(1:x3Length) temp];%temp(x3Length:end)];

%Plotting the pulses without zero padding
figure
plot(x1Sig(1:x1Length))
figure
plot(x2Sig(1:x2Length))
figure
plot(x3Sig(1:x3Length))

%Creating Recieved Signal
T = 15;                                         %Temp in C
S = 5;                                          %Salinity in parts per thousand
D = 10;                                         %Depth
v = calculateSoundSpeedInWater(T, S, D);        %Sound speed in water

%Bouy positions relative to bouy A in meters. Change these to test
%performance for different configurations of bouy postions. 
%PS: For the algortihm to work, A has to be at 0.0, B has to be at x.0 and
%C has to be at 0.y. So change xb and yc only!!
xa = 0;
ya = 0;
za = 0;

xb = 10;
yb = 0;
zb = 0;

xc = 0;
yc = 10;
zc = 0;

%Cheating to get correct propagation times from bouy to ROV
%ROV position

%This is the actal position of ROV in meters. Change these to test performance with
%different ROV positions.
xs = 5;
ys = 7;
zs = D;  







recSigLength = min(min(length(x1Rec), length(x2Rec)), length(x3Rec));

%recSignal would be the signal recieved on the ROV in a practical case. This is
%all three bouy signals added together with the correct propagation delay.
%This signal would also(usualy and hopefully) include 2 peaks from each
%bouy so that TDOA is possible to calculate
recSignal = x1Rec(1:recSigLength) + x2Rec(1:recSigLength) + x3Rec(1:recSigLength);

figure
plot(recSignal)
%FFT of recorded signal
frikkFFT(recSignal, Fs);



%% Filter Design
%Here three filters are designed to extract the signal from each of the
%bouys. The filter design process is computationally heavy and is only
%necessary to perform if pbw, sbw or Fs is changed. 

pbw = 1000; % Passband width in hertz
sbw = 4000; % Stopband width in hertz
b1 = frikkFilterDesigner( f1, pbw, sbw, Fs );
b2 = frikkFilterDesigner( f2, pbw, sbw, Fs );
b3 = frikkFilterDesigner( f3, pbw, sbw, Fs );

%% Filtering and smoothing
%Here each of bouy signals are abseda and filtered with their corresponding filter
%from above, and a moving average is performed in order to smooth/LP-filter
%the signals. smoothingCoeff determines how many adjacent datapoint are
%used in the smoothing process. 
smoothingCoeff = 20;
extracted1 = filterAndSmooth(recSignal, b1, smoothingCoeff);
extracted2 = filterAndSmooth(recSignal, b2, smoothingCoeff);
extracted3 = filterAndSmooth(recSignal, b3, smoothingCoeff);

%% Plotting filtered, absed and smoothed Signals
figure
plot(extracted1)
figure
plot(extracted2)
figure
plot(extracted3)


%% Detection stuff
addedDelay = .1; % The chosen set delay-time between pulses
detectionThreshold = .05; % A threshold for how strong a signal needs to be on order to be detected as a recieved pulse.
% This function calculates the x and y coordinates of the ROV.
%In reality, when implemented this would be the only necesary function to
%run as all other parameters should be set.
[x, y] = getPositionFromSignal( recSignal, b1, b2, b3, Fs, v, addedDelay, detectionThreshold, D, xa, ya, za, xb, yb, zb, xc, yc, zc )







