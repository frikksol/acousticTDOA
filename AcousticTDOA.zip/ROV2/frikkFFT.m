function frikkFFT( X, Fs )
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here

NFFT = length(X)/2;
%NFFT = Fs/10;%length(recSignal);
Y = fft(X, NFFT);
%L = length(recSignal);
L = NFFT;
%P2 = abs(Y/L);
P2 = abs(Y);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);

f = Fs*(0:(L/2))/L;
figure
plot(f,P1)
title('Single-Sided Amplitude Spectrum of X(t)')
xlabel('f (Hz)')
ylabel('|P1(f)|')

end

