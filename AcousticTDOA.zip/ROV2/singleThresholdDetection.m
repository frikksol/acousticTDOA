function [ position ] = singleThresholdDetection( x, threshold )

position = 0;

for i = 1:length(x)
    if x(i) >= threshold
        position = i;
        break
    end
end


end

