function [ tdoa, tdoaLength ] = TDOA( x, Fs, v, addedDelay, detectionTreshold )
%Designed by Frikk H Solberg
%This funciton calclulates the TDOA for signal x, given that x is filtered
%and only consist of two pulses. It also uses sampling rate Fs, sound speed
%in water v, addedDelay, which is the added delay between pulses and the
%detectionTreshold.


%Maximum time traveled for sound in water over 100m range
%TW = 0.07;
TW = 0;
expectedDelay = round((TW + addedDelay)*Fs);
calculationCoeff = 1; %This variable can be changed for tuning the performance of the detection algorithm.

figure
plot(x(expectedDelay:end))

lastPeak = expectedDelay + singleThresholdDetection(x(expectedDelay:end), detectionTreshold);
firstPeakTemp = singleThresholdDetection(fliplr(x(1:(lastPeak-5))), detectionTreshold);
firstPeak = lastPeak - firstPeakTemp - 5;

tdoa = ((lastPeak - firstPeak)/Fs - addedDelay) * calculationCoeff;
tdoaLength = tdoa * v;

end

