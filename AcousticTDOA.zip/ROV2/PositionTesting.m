
%Initial stuff. Should come from sensors or from user inputs dependant on
%where one dives
T = 15;      %Temp in C
t = T/10;
S = 5;       %Salinity in parts per thousand
D = 0.1;     %depth in km. This is the ROV depth and should come from a depth sensor on the ROV


%calculating water speed
v0 = 1449.05 + 45.7*t - 5.21*t*t + .23*t*t*t + (1.333 - .126*t + .009*t*t) * (S - 35);  %initial water propagation speed
v = v0 + (16.23 + .253*t)*D + (.213 - .1*t)*D*D + (.016 + .0002*(S - 35)) * (S - 35);   %water propagation speed


%Bouy positions
xa = 0;
ya = 0;
za = 0;

xb = .1;
yb = 0;
zb = 0;

xc = 0;
yc = .1;
zc = 0;

%Cheating to get correct propagation times from bouy to ROV
xs = 2;
ys = 2;
zs = D;    %which is equal to D


dsaTemp = sqrt(D*D + (xs - xa)*(xs - xa) + (ys - ya)*(ys - ya));
dsbTemp = sqrt(D*D + (xs - xb)*(xs - xb) + (ys - yb)*(ys - yb));
dscTemp = sqrt(D*D + (xs - xc)*(xs - xc) + (ys - yc)*(ys - yc));

tsa = dsaTemp/v;
tsb = dsbTemp/v;
tsc = dscTemp/v;

%THE ACTUAL ALGORITHM
%calculating from time to distance
dsa = v*tsa;
dsb = v*tsb;
dsc = v*tsc;

%Projecting to plane to move from 3D to 2D
dsaProjected = sqrt(dsa*dsa - D*D);
dsbProjected = sqrt(dsb*dsb - D*D);
dscProjected = sqrt(dsc*dsc - D*D);

x = (dsaProjected*dsaProjected - dsbProjected*dsbProjected + xb*xb )/(2*xb)
y = ((dsaProjected*dsaProjected - dscProjected*dscProjected + xc*xc + yc*yc)/(2*yc)) - ((xc)/(yc))*x
