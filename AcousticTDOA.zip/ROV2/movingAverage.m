function [ dataMovAvg ] = movingAverage( input, movAvgParam )

%movAvgParam = 10;
dataMovAvg = zeros(1, length(input));
for i = 1: length(input)
    start = i - movAvgParam;
    finish = i + movAvgParam;
    if start < 1
        start = 1;
    end
    if finish > length(input);
        finish = length(input);
    end
        
    dataMovAvg(i) = mean(input(start:finish)); 
end



end

