function [ x, y ] = getPositionFromSingal( x, b1, b2, b3, Fs, v, addedDelay, detectionThreshold, D, xa, ya, za, xb, yb, zb, xc, yc, zc )
%UNTITLED14 Summary of this function goes here
%   Detailed explanation goes here

smoothingCoeff = 20;
extracted1 = filterAndSmooth(x, b1, smoothingCoeff);
extracted2 = filterAndSmooth(x, b2, smoothingCoeff);
extracted3 = filterAndSmooth(x, b3, smoothingCoeff);

[tdoa1, tdoaLength1] = TDOA( extracted1, Fs, v, addedDelay , detectionThreshold);
[tdoa2, tdoaLength2] = TDOA( extracted2, Fs, v, addedDelay , detectionThreshold);
[tdoa3, tdoaLength3] = TDOA( extracted3, Fs, v, addedDelay , detectionThreshold);

[x, y] = calculateProjectedCoordinates( D, v, tdoa1, tdoa2, tdoa3, xa, ya, za, xb, yb, zb, xc, yc, zc );

end

