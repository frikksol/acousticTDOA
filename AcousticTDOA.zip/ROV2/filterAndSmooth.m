function [ YMA ] = filterAndSmooth( X, b, smoothingCoeff )

Y = filter(b, 1, X);
YMA = movingAverage(abs(Y), smoothingCoeff);

end

