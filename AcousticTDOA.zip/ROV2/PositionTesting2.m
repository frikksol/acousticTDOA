
%Initial stuff. Should come from sensors or from user inputs dependant on
%where one dives
T = 15;      %Temp in C
S = 5;       %Salinity in parts per thousand
D = 0.1;     %depth in km. This is the ROV depth and should come from a depth sensor on the ROV

%Bouy positions
xa = 0;
ya = 0;
za = 0;

xb = .1;
yb = 0;
zb = 0;

xc = 0;
yc = .1;
zc = 0;

%Cheating to get correct propagation times from bouy to ROV
xs = 2;
ys = 2;
zs = D;    %which is equal to D


dsaTemp = sqrt(D*D + (xs - xa)*(xs - xa) + (ys - ya)*(ys - ya));
dsbTemp = sqrt(D*D + (xs - xb)*(xs - xb) + (ys - yb)*(ys - yb));
dscTemp = sqrt(D*D + (xs - xc)*(xs - xc) + (ys - yc)*(ys - yc));

tsa = dsaTemp/v;
tsb = dsbTemp/v;
tsc = dscTemp/v;

%The Algorithm
%calculating water speed
v = calculateSoundSpeedInWater(T, S, D);
[x, y] = calculateProjectedCoordinates( D, v, tsa, tsb, tsc, xa, ya, za, xb, yb, zb, xc, yc, zc );

