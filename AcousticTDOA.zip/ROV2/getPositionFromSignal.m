function [ x, y ] = getPositionFromSignal( x, b1, b2, b3, Fs, v, addedDelay, detectionThreshold, D, xa, ya, za, xb, yb, zb, xc, yc, zc )
% Designed by Frikk H Solberg
%This function calculates x and y cordinates of ROV from a bunch of inputs:
%x: recieved signal containing all three pulses.
%b1: filter coeffs for bouy A 
%b2: filter coeffs for bouy B 
%b3: filter coeffs for bouy C 
%Fs: Sampling frequency
%v: sound speed in water
%addedDelay: The set delay between pulsees from the bouys
%detectionThreshold: the threshold for what would be detected as a recieved
%pulse
%D: depth from depth sensor
%xa: bouy A x position
%ya: bouy A y position
%xb: bouy B x position
%yb: bouy B y position
%xc: bouy C x position
%yc: bouy C y position

smoothingCoeff = 20; % Smoothing coeff is set here as this setting works best.

%Extracting the individual signals from each bouy
extracted1 = filterAndSmooth(x, b1, smoothingCoeff);
extracted2 = filterAndSmooth(x, b2, smoothingCoeff);
extracted3 = filterAndSmooth(x, b3, smoothingCoeff);

%Calculating the TDOA for each of the different bouy signals
[tdoa1, tdoaLength1] = TDOA( extracted1, Fs, v, addedDelay , detectionThreshold);
[tdoa2, tdoaLength2] = TDOA( extracted2, Fs, v, addedDelay , detectionThreshold);
[tdoa3, tdoaLength3] = TDOA( extracted3, Fs, v, addedDelay , detectionThreshold);

%Calculating the x and y positions of ROV from the different TDOA signals
[x, y] = calculateProjectedCoordinates( D, v, tdoa1, tdoa2, tdoa3, xa, ya, za, xb, yb, zb, xc, yc, zc );

end

