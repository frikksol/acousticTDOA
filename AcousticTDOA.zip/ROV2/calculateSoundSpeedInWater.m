function [ v ] = calculateSoundSpeedInWater( T, S, Dmeters )
D = Dmeters/1000;
t = T/10;

%calculating water speed
v0 = 1449.05 + 45.7*t - 5.21*t*t + .23*t*t*t + (1.333 - .126*t + .009*t*t) * (S - 35);  %initial water propagation speed
v = v0 + (16.23 + .253*t)*D + (.213 - .1*t)*D*D + (.016 + .0002*(S - 35)) * (S - 35);   %water propagation speed

end

